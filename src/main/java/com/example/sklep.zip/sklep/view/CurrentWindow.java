package com.example.sklep.view;

public enum CurrentWindow {
    LOGIN,
    REGISTER,
    ADMIN,
    SELLER
}
