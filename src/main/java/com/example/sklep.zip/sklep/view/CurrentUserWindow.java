package com.example.sklep.view;

public enum CurrentUserWindow {
    ADMIN,
    ADDSELLER,
    ORDER
}
